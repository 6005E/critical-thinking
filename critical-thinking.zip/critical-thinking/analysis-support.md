# Analysis Support

Load when Q2 (argument structure) or Q5 (knowledge gaps) fires in triage. Also loads via flaw handling when a false dichotomy is identified.

For causal, statistical, and evidence-quality reasoning in research interpretation tasks, also load analytical.md.

---

## Argument Structure

- When an argument relies on an analogy, does it hold in the specific ways that matter for the conclusion?
- Are comparison criteria appropriate for the decision — not just the most obvious criteria? When a benchmark or reference group is used, check whether its composition is comparable: outperforming an average of unlike things is weak evidence of genuine outperformance.
- When an argument has multiple premises, are all of them necessary — do they all contribute to the conclusion?
- Does a logical gap exist between the premises and the conclusion, or does the conclusion actually follow?
- When a claim is doing significant argumentative work or is being stated with high confidence, structure it explicitly: state the evidence, then the inference, then assess whether the inference is the only reasonable one or whether alternative inferences exist.
- When encountering a counterargument, has it been engaged with in its strongest form rather than a weakened version — steelmanned rather than strawmanned?
- When an argument dismisses opposition by attacking the character, motives, or knowledge of opponents rather than engaging with their arguments, identify this as an ad hominem and steelman the opposition before proceeding.
- Is the argument presenting a false dichotomy — only two options when more exist? If so, name it explicitly, identify the excluded alternatives, and restructure the response around the corrected framing before engaging with the comparison as posed.
- When interpreting a text to attribute intent, strategy, or awareness to an author, identify at least one equally plausible alternative reading before committing to the interpretation. If alternatives exist and cannot be ruled out, present the interpretation as one reading rather than the reading.
- When a prior investment, outcome, or decision is used as evidence for a new one, check whether the conditions that produced the prior outcome are present in the new case. Past success is not transferable evidence unless the causal mechanism is the same.
- When an argument projects a downstream outcome from a proposed action, check whether that outcome feeds back into the causal chain — reinforcing or undermining the initial conditions. One-directional causal models applied to systems with feedback loops will systematically misestimate the magnitude, and sometimes the direction, of effect.
- When an argument's evidence only supports its conclusion if the conclusion is already assumed to be true, identify this as circular reasoning. The diagnostic test: remove the conclusion and ask whether the evidence still points to it independently. If the evidence requires the conclusion to be interpreted as evidence, the argument is circular.
- When familiarity or unfamiliarity with a source, institution, method, or person is being used as a quality signal, check whether the familiarity is evidence of quality or evidence of the evaluator's exposure. Unfamiliarity warrants investigation, not discounting. Familiarity warrants scrutiny, not automatic trust.
- When an argument chains a series of consequences from an initial action to a harmful endpoint, check each link independently: (1) is each intermediate step probable, not merely possible; (2) does each step follow necessarily from the prior, or does it require additional conditions that may not hold; (3) are there mechanisms that would arrest the chain before the endpoint; (4) is the argument's persuasive force coming from the endpoint rather than from establishing the chain. If intermediate steps are asserted without evidence, the argument is a slippery slope regardless of whether the endpoint is genuinely bad.
- When an argument frames a proposed action as the solution to a problem caused by the current state, check whether the proposed action has been evaluated for its own consequences — not only relative to the current state but in absolute terms. The status quo is not a neutral baseline; neither is the intervention. Both carry consequence chains that must be assessed independently.
- When a conclusion about a population, system, or future state is drawn from a limited sample, check whether the sample is large enough, representative enough, and collected under sufficiently similar conditions to support the generalization. A track record under past conditions does not establish performance under novel ones. Absence of detected problems in a sample is not evidence of absence in the population.
- When a professional assessment establishes merit — legal strength, clinical efficacy, technical correctness — check whether merit in that domain translates to the practical outcome being sought. Merit and outcome are assessed in different domains: a strong legal case may produce an unenforceable judgment; an efficacious treatment may not work in a specific patient; a theoretically correct solution may fail in the actual environment. Assess both independently.
- When an argument chains evidence through escalating claim types — from satisfaction to effectiveness, from effectiveness to scalability, from correlation to causation, from pilot to full rollout — check whether the evidence standard escalates appropriately at each step. Evidence adequate for one claim type is not automatically adequate for the next. Flag the step where the evidence standard is exceeded without acknowledgment.

---

## Source Quality and Knowledge Gaps

- When a knowledge gap cannot be resolved through available search, what specific material would resolve it — and has that been communicated to the user in terms concrete enough to act on? Name the document type, the specific section or content needed, and why it would resolve the gap.
- When searching for information, prefer primary sources: manufacturer datasheets over aggregators, government regulations over summaries, peer-reviewed papers over science journalism, official institutional pages over third-party descriptions.
- When a domain has a recognized authoritative body — a professional association, regulatory agency, standards organization — that body's publications are the highest-quality source for domain-specific claims.
- When search results are dominated by commercial or advocacy sources, note this explicitly and seek independent or primary sources before drawing conclusions.
- When evaluating a source, check four dimensions: relevance (does it address the specific claim), authority (is it recognized in this domain), recency (is it current enough), and independence (is it genuinely independent from other sources cited). When uncertain on any dimension, state which dimensions are unverified rather than presenting the source as fully verified.
